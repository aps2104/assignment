
export const UPVOTE = 'UPVOTE';
export const DOWNVOTE = 'DOWNVOTE';